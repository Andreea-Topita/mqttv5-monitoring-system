import threading
import time
from typing import Optional
from src.core.pagination import build_pagination
from src.client.mqtt_client import MQTTClient
from src.repositories.connection_event_repository import ConnectionEventRepository
from src.repositories.subscription_event_repository import SubscriptionEventRepository
from src.repositories.mqtt_message_repository import MQTTMessageRepository

from src.core.exceptions import (
    AlreadyConnectedError,
    BusinessValidationError,
    ConnectionFailedError,
    NotConnectedError,
    PeriodicPublishAlreadyRunningError,
    SubscriptionNotFoundError,
    PeriodicPublishNotRunningError
)


class MonitorService:
    def __init__(
        self,
        on_message_callback=None,
        connection_event_repository: Optional[ConnectionEventRepository] = None,
        subscription_event_repository: Optional[SubscriptionEventRepository] = None,
        mqtt_message_repository: Optional[MQTTMessageRepository] = None
    ):
        self.client = None
        self.connected = False
        self.periodic_publishing = False
        self.external_on_message_callback = on_message_callback

        # mesaje primite de la broker, tinute in memorie pentru UI live
        self.received_messages = []
        self.message_counter = 0

        # topic -> qos
        self.subscriptions = {}

        self.lock = threading.Lock()

        # date despre conexiunea curenta
        self.client_id = ""
        self.broker_address = ""
        self.broker_port = 1883

        # repositories
        self.connection_event_repository = connection_event_repository or ConnectionEventRepository()
        self.subscription_event_repository = subscription_event_repository or SubscriptionEventRepository()
        self.mqtt_message_repository = mqtt_message_repository or MQTTMessageRepository()

    def _persist_safely(self, action_name: str, callback, *args, **kwargs):
        try:
            callback(*args, **kwargs)
        except Exception as e:
            print(f"Persistence error during {action_name}: {e}")

    def _append_in_memory_message(self, topic: str, message: str):
        with self.lock:
            self.message_counter += 1
            self.received_messages.append({
                "id": self.message_counter,
                "topic": topic,
                "message": message,
                "timestamp": time.time()
            })

            if len(self.received_messages) > 100:
                self.received_messages.pop(0)

    def _handle_incoming_message(
        self,
        topic: str,
        message: str,
        source_client_id: Optional[str] = None
    ):
        self._append_in_memory_message(topic, message)

        with self.lock:
            current_qos = self.subscriptions.get(topic, 0)

        self._persist_safely(
            "saving inbound mqtt message",
            self.mqtt_message_repository.add_message,
            topic=topic,
            payload=message,
            qos=current_qos,
            direction="INBOUND",
            source_client_id=source_client_id
        )

        if self.external_on_message_callback:
            self.external_on_message_callback(topic, message, source_client_id)

    def connect(
        self,
        broker_address: str,
        broker_port: int,
        client_id: str,
        username: str,
        password: str,
        last_will_topic: str,
        last_will_message: str,
        last_will_qos: int,
        last_will_retain: bool = False,
    ):
        if self.connected:
            raise AlreadyConnectedError("Client is already connected to a broker.")

        if not broker_address.strip():
            raise BusinessValidationError("Broker address must not be empty.")

        if not client_id.strip():
            raise BusinessValidationError("Client ID must not be empty.")

        if not last_will_topic.strip():
            raise BusinessValidationError("Last will topic must not be empty.")

        if not last_will_message.strip():
            raise BusinessValidationError("Last will message must not be empty.")

        with self.lock:
            self.received_messages = []
            self.message_counter = 0
            self.subscriptions = {}

        self.client_id = client_id
        self.broker_address = broker_address
        self.broker_port = broker_port

        try:
            self.client = MQTTClient(
                client_id=client_id,
                on_message_callback=self._handle_incoming_message
            )

            self.client.will_set(
                last_will_topic,
                last_will_message,
                qos=last_will_qos,
                retain=last_will_retain
            )
            self.client.username_pw_set(username, password)
            self.client.conectare_broker(broker_address, broker_port)

            self.connected = True

        except Exception as e:
            self.client = None
            self.connected = False
            raise ConnectionFailedError(f"Failed to connect to broker: {e}")

        self._persist_safely(
            "saving connect event",
            self.connection_event_repository.add_event,
            client_id=client_id,
            broker_address=broker_address,
            broker_port=broker_port,
            event_type="CONNECT"
        )

    def disconnect(self):
        if not self.client or not self.connected:
            raise NotConnectedError("Client is not connected to any broker.")

        try:
            self.client.disconnect()
        finally:
            self._persist_safely(
                "saving disconnect event",
                self.connection_event_repository.add_event,
                client_id=self.client_id,
                broker_address=self.broker_address,
                broker_port=self.broker_port,
                event_type="DISCONNECT"
            )

        self.connected = False
        self.periodic_publishing = False
        self.client = None

        with self.lock:
            self.subscriptions.clear()

    def publish_message(self, topic: str, message: str, qos: int):
        if not self.client or not self.connected:
            raise NotConnectedError("Client is not connected to broker.")

        if not topic or not topic.strip():
            raise BusinessValidationError("Topic must not be empty.")

        self.client.publish(topic, message, qos)

        self._persist_safely(
            "saving outbound mqtt message",
            self.mqtt_message_repository.add_message,
            topic=topic,
            payload=message,
            qos=qos,
            direction="OUTBOUND",
            source_client_id=self.client_id
        )

    def subscribe(self, topic: str, qos: int):
        if not self.client or not self.connected:
            raise NotConnectedError("Client is not connected to broker.")

        if not topic or not topic.strip():
            raise BusinessValidationError("Topic must not be empty.")

        self.client.subscribe(topic, qos)

        with self.lock:
            self.subscriptions[topic] = qos

        self._persist_safely(
            "saving subscribe event",
            self.subscription_event_repository.add_event,
            topic=topic,
            qos=qos,
            action="SUBSCRIBE"
        )

    def unsubscribe(self, topic: str):
        if not self.client or not self.connected:
            raise NotConnectedError("Client is not connected to broker.")

        if not topic or not topic.strip():
            raise BusinessValidationError("Topic must not be empty.")

        with self.lock:
            if topic not in self.subscriptions:
                raise SubscriptionNotFoundError(
                    f"Topic '{topic}' is not currently subscribed."
                )
            old_qos = self.subscriptions[topic]

        self.client.unsubscribe(topic)

        with self.lock:
            del self.subscriptions[topic]

        self._persist_safely(
            "saving unsubscribe event",
            self.subscription_event_repository.add_event,
            topic=topic,
            qos=old_qos,
            action="UNSUBSCRIBE"
        )

    def start_periodic_publish(
        self,
        topic: str,
        message: str,
        qos: int,
        interval: int = 5
    ):
        if not self.connected:
            raise NotConnectedError("Client is not connected to broker.")

        if not topic or not topic.strip():
            raise BusinessValidationError("Topic must not be empty.")

        if interval <= 0:
            raise BusinessValidationError("Interval must be greater than 0.")

        if self.periodic_publishing:
            raise PeriodicPublishAlreadyRunningError(
                "Periodic publishing is already running."
            )

        self.periodic_publishing = True
        threading.Thread(
            target=self._publish_periodically,
            args=(topic, message, qos, interval),
            daemon=True
        ).start()

    def _publish_periodically(self, topic: str, message: str, qos: int, interval: int):
        while self.periodic_publishing:
            try:
                self.publish_message(topic, message, qos)
            except Exception as e:
                print(f"Periodic publish error: {e}")
            time.sleep(interval)

    def stop_periodic_publish(self):
        if not self.periodic_publishing:
            raise PeriodicPublishNotRunningError("Periodic publishing is not running.")

        self.periodic_publishing = False

    def get_messages(self, topic: Optional[str] = None, after_id: Optional[int] = None):
        with self.lock:
            messages = list(self.received_messages)

        if topic:
            messages = [msg for msg in messages if msg["topic"] == topic]

        if after_id is not None:
            messages = [msg for msg in messages if msg["id"] > after_id]

        return messages

    def get_status(self):
        with self.lock:
            return {
                "connected": self.connected,
                "periodic_publishing": self.periodic_publishing,
                "subscriptions": dict(self.subscriptions)
            }

    def get_message_history(
        self,
        topic: Optional[str] = None,
        direction: Optional[str] = None,
        page: int = 1,
        page_size: int = 20
    ):
        rows, total_items = self.mqtt_message_repository.get_messages_paginated(
            topic=topic,
            direction=direction,
            page=page,
            page_size=page_size
        )

        pagination = build_pagination(page, page_size, total_items)

        return rows, pagination